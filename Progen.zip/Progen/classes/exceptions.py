class ExitScript(Exception):
    pass